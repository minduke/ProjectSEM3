﻿CREATE DATABASE [GiveAID]
GO
USE [GiveAID]
GO
/****** Object:  Table [dbo].[banner]    Script Date: 10/06/2024 14:56:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[banner](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[banner_image] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[category]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[category](
	[cate_id] [int] IDENTITY(1,1) NOT NULL,
	[name] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[cate_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[configuration]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[configuration](
	[keyword] [varchar](255) NOT NULL,
	[value] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[keyword] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[image_post]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[image_post](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[image] [varchar](max) NULL,
	[post_id] [int] NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[partner]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[partner](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[partner_name] [nvarchar](100) NULL,
	[partner_image] [varchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[address] [nvarchar](200) NULL,
	[phone] [varchar](50) NULL,
	[email] [varchar](100) NULL,
	[partner_status] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[payment]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[payment](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[post_id] [int] NULL,
	[user_id] [int] NULL,
	[transaction_amout] [decimal](18, 2) NULL,
	[transaction_no] [varchar](max) NULL,
	[transaction_date] [datetime] NULL,
	[banktran_no] [varchar](50) NULL,
	[pay_status] [nvarchar](50) NULL,
	[anonymous] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[post]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[post](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[title] [nvarchar](max) NULL,
	[description] [nvarchar](max) NULL,
	[content] [ntext] NULL,
	[image] [varchar](max) NULL,
	[time_start] [date] NULL,
	[time_end] [date] NULL,
	[target] [decimal](18, 2) NULL,
	[cate_id] [int] NULL,
	[partner_id] [int] NULL,
	[status] [nvarchar](10) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[user]    Script Date: 10/06/2024 14:56:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[user](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[username] [varchar](50) NULL,
	[password] [varchar](50) NULL,
	[fullname] [nvarchar](100) NULL,
	[image] [varchar](max) NULL,
	[phone] [varchar](11) NULL,
	[email] [varchar](100) NULL,
	[permission] [nvarchar](50) NULL,
	[gender] [nvarchar](10) NULL,
	[address] [nvarchar](max) NULL,
	[status] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_ADDRESS', N'102 Nguyễn Đình Chính, phường Đính Đá, Quận Đình Chỉ, TPHCM')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_DISPLAY_NAME', N'Give.AID')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_EMAIL', N'Give.AID@gmail.com')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_IMAGE_FOOTER', N'638536270222455645_sloganVIP.jpg')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_INTRODUCE', N'Tổ chức phi chính phủ tiêu chí đi đầu vì người dân mà cống hiến hết mình hết hết tâm trí lí trí con người')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_INTRODUCE_FOOTER', N'GIVE-AID ALWAYS WANT TO BRING JOY AND HAPPINESS TO EVERYONE')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_LOGO', N'638536270222289295_LogoGive.png')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_MAIL_ADDRESS', N'Give.AID@gmail.com')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_MAIL_PASS', N'fpBjWK53hc1UwoS1p4fUdqaPUY76rHNd')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_MAIL_PORT', N'587')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_MAIL_USERNAME', N'Give.AID@gmail.com')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_PHONE', N'8456490734012')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_SMTP_SERVER', N'smtp.gmail.com')
INSERT [dbo].[configuration] ([keyword], [value]) VALUES (N'SYS_SSL', N'true')
GO
SET IDENTITY_INSERT [dbo].[user] ON 

INSERT [dbo].[user] ([id], [username], [password], [fullname], [image], [phone], [email], [permission], [gender], [address], [status]) VALUES (2, N'minhduc', N'epsjGLfTuiQ=', N'Lê Minh Đức', N'user-profile.png', N'0907420625', N'leduc20198@gmail.com', N'admin', N'', N'', N'active')

INSERT [dbo].[user] ([id], [username], [password], [fullname], [image], [phone], [email], [permission], [gender], [address], [status]) VALUES (1, N'admin', N'epsjGLfTuiQ=', N'Đệ Tử Anh Khiêm', N'user-profile.png', N'0765500229', N'Give.AID@gmail.com', N'admin', N'', N'Anh em bốn bể giang hồ máu rơi không biết bao nhiêu lần', N'active')
SET IDENTITY_INSERT [dbo].[user] OFF
GO
ALTER TABLE [dbo].[payment] ADD  DEFAULT ('') FOR [banktran_no]
GO
ALTER TABLE [dbo].[payment] ADD  DEFAULT ('') FOR [pay_status]
GO
ALTER TABLE [dbo].[image_post]  WITH CHECK ADD  CONSTRAINT [FK_post_image_id] FOREIGN KEY([post_id])
REFERENCES [dbo].[post] ([id])
GO
ALTER TABLE [dbo].[image_post] CHECK CONSTRAINT [FK_post_image_id]
GO
ALTER TABLE [dbo].[payment]  WITH CHECK ADD  CONSTRAINT [FK_post_id] FOREIGN KEY([post_id])
REFERENCES [dbo].[post] ([id])
GO
ALTER TABLE [dbo].[payment] CHECK CONSTRAINT [FK_post_id]
GO
ALTER TABLE [dbo].[payment]  WITH CHECK ADD  CONSTRAINT [FK_user_id] FOREIGN KEY([user_id])
REFERENCES [dbo].[user] ([id])
GO
ALTER TABLE [dbo].[payment] CHECK CONSTRAINT [FK_user_id]
GO
ALTER TABLE [dbo].[post]  WITH CHECK ADD  CONSTRAINT [FK_cate_id] FOREIGN KEY([cate_id])
REFERENCES [dbo].[category] ([cate_id])
GO
ALTER TABLE [dbo].[post] CHECK CONSTRAINT [FK_cate_id]
GO
ALTER TABLE [dbo].[post]  WITH CHECK ADD  CONSTRAINT [FK_partner_id] FOREIGN KEY([partner_id])
REFERENCES [dbo].[partner] ([id])
GO
ALTER TABLE [dbo].[post] CHECK CONSTRAINT [FK_partner_id]
GO
